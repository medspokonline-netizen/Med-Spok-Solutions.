# Medspok Solutions — website

The website for Med Spok Solutions Pvt Ltd, Porur, Chennai.

Six pages of plain HTML. **There is no build step and no configuration file.** That is
deliberate: nothing here can fail during a deploy, because nothing is compiled.

## Deploying

### Vercel

1. Push these files to a GitHub repository. `index.html` must appear in the repository's
   file list — **not** inside a folder.
2. Vercel: **Add New → Project → Import** the repository → **Deploy**.
3. Leave every setting alone. Framework Preset shows **Other**, Build Command, Output
   Directory and Root Directory are all empty. That is correct.

**Do not add `package.json` or `vercel.json`.** Both cause the deploy to fail:

- `package.json` makes Vercel run `npm run build`, which this site does not have →
  `MODULE_NOT_FOUND`, build exits 1
- `vercel.json` with `outputDirectory` makes Vercel look for a build folder that does not
  exist → `404: NOT_FOUND` on every page

### Netlify

Drag this whole folder onto [app.netlify.com/drop](https://app.netlify.com/drop). Live in
about ten seconds, no settings.

### Checking it first

Double-click `index.html`. The site opens in your browser exactly as it will appear online.

## What is here

```
index.html          Home
products.html       Full range, 13 product lines, specification tables
rent-or-buy.html    Rent vs buy, with the situation picker
services.html       Installation, AMC/CMC, consumables, setup film
about.html          Company, premises, brand partners
contact.html        Enquiry form, phone numbers, map
robots.txt          For search engines
sitemap.xml         List of pages for Google
site.webmanifest    Icons and name when saved to a phone home screen
assets/
  style.css         All styling
  site.js           Menu, picker, photo viewer, enquiry form
  products/         Product photography
  premises/         Shopfront and stockroom
  brands/           Manufacturer logos
  icons/            Favicons
  video/            Concentrator setup film (12 MB, streams on demand)
  medspok-catalogue-2026.pdf
```

Total 16 MB. No page is larger than 1.9 MB — the film is a separate file, so it downloads
only when someone presses play.

## Editing later

| To change | Where |
|---|---|
| Phone numbers | Top bar and footer of every `.html` file, plus `WHATSAPP` at the top of `assets/site.js` |
| Email address | Same places, plus `MAIL` in `assets/site.js` |
| Colours and fonts | The `:root` block at the top of `assets/style.css` |
| Rent-or-buy advice | The `CASES` object in `assets/site.js` |
| Adding a product | Copy an existing `<div class="card">` block in `products.html` |

## Adding your own domain

Buy `medspok.in` (roughly ₹700–1,200 a year). In Vercel: **Settings → Domains → Add**. In
Netlify: **Domain management → Add a domain**. Then update the `<link rel="canonical">` and
Open Graph tags at the top of each page, and the URLs in `sitemap.xml` and `robots.txt` —
they currently read `https://www.medspok.in/` as a placeholder.

## Two things still open

**Manufacturer logos.** The site shows Home Medix, BMC, ResMed and SVASTEK logos and product
photography, and the services page carries a setup film produced by Home Medix. Normal for an
authorized dealer, but each manufacturer has brand guidelines — ResMed is the strictest.
Worth an email to all four.

**The company name.** The site says *Med Spok Solutions Pvt Ltd*, following the catalogue.
Your signboard says *MEDSPOK SOLUTIONS PVT LTD*. Use whichever matches the incorporation
certificate; it appears in every page footer and in the structured data Google reads.

## Verified

Checked before delivery, on the exact files in this folder:

- Link and structure check across all six pages — passed
- HTML validator (Tidy) — no errors
- `site.js` syntax, `style.css` braces — OK
- Browser test, 27 checks — all six pages load styled with the logo and no broken images,
  navigation works, all seven picker situations respond, the photo viewer opens and closes,
  enquiry links carry the model name and select the right category, the film streams on
  demand, the catalogue downloads, the phone menu works, no 404s, no console errors
